import React from 'react'

import { NavigationContainer } from '@react-navigation/native'
import { createNativeStackNavigator } from '@react-navigation/native-stack'

import HomeScreen from './Home/HomeScreen'
import ListScreen from './ListContacts/ListScreen'
import SosScreen from './Sos/SosScreen'

const Stack = createNativeStackNavigator();

export default () => {
  return(
    <NavigationContainer>
      <Stack.Navigator initialRouteName='home' screenOptions={defaultOptions}>
        <Stack.Screen name='home' component={HomeScreen} options={homeOptions} />
        <Stack.Screen name='listContact' component={ListScreen} options={listOptions}/>
        <Stack.Screen name='sos' component={SosScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  )
}

const defaultOptions = {
  headerStyle: {
    backgroundColor: '#25CCB0'
  },
  headerTintColor: 'white',
  headerTitleStyle: {
    fontWeight: 'bold'
  }
}

const homeOptions = {
  headerShown: false
}

const listOptions = {
  title: 'Lista de contatos SOS'
}


