import React from 'react'
import {Text, StyleSheet, TouchableOpacity} from 'react-native'

export default ({color='#25CCB0', title='Não informado', onPress}) => (
    <TouchableOpacity
      style={[styles.botao, {backgroundColor: color}]}
      onPress={onPress}
    >
      <Text style={styles.texto}>{title.toUpperCase()}</Text>
    </TouchableOpacity>
)

const styles = StyleSheet.create({
  botao: {
    height: 65,
    borderRadius: 35,
    justifyContent: 'center',
    alignItems: 'center'
  },
  texto: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white'
  }
})
