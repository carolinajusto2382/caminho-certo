import React from 'react'
import {View, Text, Image, StyleSheet} from 'react-native'

import Constants from 'expo-constants'

import Logo from '../assets/logo.png'

export default () => {
  return (
    <View style={styles.header}>
      <Text style={[styles.fontePadrao, styles.titulo]}>Caminho Certo</Text>
      <Image source={Logo} style={styles.imagem} />
    </View>
  )
} 

const styles = StyleSheet.create({
  header: {
    alignItems: 'center',
    backgroundColor: '#25CCB0',
    paddingTop: Constants.statusBarHeight,
    paddingBottom: 10
  },
  fontePadrao: {
    fontFamily: 'Roboto'
  },
  titulo: {
    fontWeight: 'bold',
    fontSize: 26,
    color: 'white'
  },
  imagem: {
    width: 100,
    height: 100,
    borderRadius: 100
  }
})