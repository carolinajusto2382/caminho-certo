import React from 'react'
import {View, Text, Button, StyleSheet} from 'react-native'

import Header from './Header'
import CustomButton from './CustomButton'

export default ({navigation, route}) => {
  return (
    <View style={styles.container}>
      <Header />
      <View style={styles.botoes}>
        <CustomButton 
          color='red'
          title='SOS'
          onPress={() => navigation.navigate('listContact')}
        />
        <CustomButton 
          color='#25CCB0'
          title='Registro'
          onPress={() => alert('Clique no botão Registro')}
        />
        <CustomButton 
          color='#25CCB0'
          title='Rastreio'
          onPress={() => alert('Clique no botão Rastreio')}
        />
        
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  botoes: {
    flex: 1,
    justifyContent: 'space-around',
    padding: '5%'
  }
})
