import React from 'react'
import {View, Text, StyleSheet, Image, TouchableOpacity} from 'react-native'
import { AntDesign } from '@expo/vector-icons';

export default ({foto, tipo, nome, telefone, onEdit, onDelete}) => (
  <View style={styles.viewCard}>
    <Image source={{uri: foto}} style={styles.foto} />
    <View style={styles.infoCard}>
      <Text style={styles.textCard}>{tipo}</Text>
      <Text style={styles.textCard}>{nome}</Text>
      <Text style={styles.textCard}>{telefone}</Text>
    </View>
    <TouchableOpacity onPress={onEdit}>
      <AntDesign name="edit" size={24} color="black" />
    </TouchableOpacity>
    <TouchableOpacity onPress={onDelete}>
      <AntDesign name="delete" size={24} color="black" />
    </TouchableOpacity>
  </View>
)

const styles = StyleSheet.create({
  viewCard: {
    flexDirection: 'row',
    padding: 5,
    alignItems: 'center'
  },
  infoCard: {
    flex: 1,
    justifyContent: 'center',
    padding: 10
  },  
  foto: {
    width: 80,
    height: 100,
    borderRadius: 12,
    elevation: 8
  },
  textCard: {
    fontFamily: 'Roboto',
    fontWeight: 'bold',
    fontSize: 16
  }
})