import React, {useState, useEffect, useRef} from 'react'
import {View, FlatList, Text, StyleSheet, TouchableOpacity} from 'react-native'
import Constants from 'expo-constants'
import {Button, Provider, Portal, Dialog, TextInput} from 'react-native-paper'

import AsyncStorage from '@react-native-async-storage/async-storage';
import uuid from 'react-native-uuid'


import Card from './Card'

const uriFoto = {uri: 'https://images.pexels.com/photos/2328141/pexels-photo-2328141.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'}

/*
const nomes = [
  {id: 1, foto: uriFoto, tipo: 'FILHA', nome: 'LARISSA', telefone: '(31) 98877-1111' },
  {id: 2, foto: uriFoto, tipo: 'FILHA', nome: 'KAMILLA', telefone: '(31) 98877-2222' },
  {id: 3, foto: uriFoto, tipo: 'FILHA', nome: 'ANA CLARA', telefone: '(31) 98877-3333' },
  {id: 4, foto: 
  uriFoto, tipo: 'FILHA', nome: 'ANA LUÍSA', telefone: '(31) 98877-4444' },
]
*/

export default ({navigation}) => {
  const [visible, setVisible] = useState(false)
  const [tipo, setTipo] = useState('')
  const [nome, setNome] = useState('')
  const [telefone, setTelefone] = useState('')
  const [nomes, setNomes] = useState([])
  const id = useRef(null)

  useEffect(() => {
    consultarContatos()
  }, [])

  const consultarContatos = async () => {
    //await AsyncStorage.clear()

    const jsonValue = await AsyncStorage
                              .getItem('@contatos')
                              .then(JSON.parse) || []
    
    setNomes(jsonValue)
  }

  const salvar = async () => {
    const registro = {
      tipo,
      nome,
      telefone,
      foto: uriFoto.uri
    }
    
    if(id.current) {
      const contato = nomes.find(c => c.id === id.current)
      contato.nome = nome
      contato.telefone = telefone
      contato.tipo = tipo
    } else {
      registro.id = uuid.v4()
      nomes.push(registro)
    }

    const jsonValue = JSON.stringify(nomes)
    await AsyncStorage.setItem('@contatos', jsonValue)

    alert('Contato registrado com sucesso!')
    setVisible(false)
    setTipo('')
    setNome('')
    setTelefone('')
    id.current = null
  }

  const excluirContato = async (id) => {
      
      const novaListaContatos = nomes.filter(c => c.id !== id)

      await AsyncStorage.setItem('@contatos', JSON.stringify(novaListaContatos))
      
      setNomes(novaListaContatos)
      alert('Contato excluido com sucesso!')
  }

  return (
    <Provider>
      <View style={styles.container}>
        <FlatList 
          data={nomes}
          renderItem={({item}) => 
            <TouchableOpacity onPress={() => navigation.navigate('sos', {contato: item})}>
              <Card 
                {...item}
                onDelete={() => excluirContato(item.id)}
                onEdit={() => {
                  setVisible(true)
                  setTipo(item.tipo)
                  setNome(item.nome)
                  setTelefone(item.telefone)
                  id.current = item.id
                }}
              />
            </TouchableOpacity>
          }
          keyExtractor={(item, index) => index }
        />
        <Button mode="contained" onPress={() => setVisible(true)}>
          Adicionar Contato
        </Button>

        <Button mode="contained" onPress={() => navigation.popToTop()}>
          Voltar
        </Button>
      </View>
      <Portal>
        <Dialog visible={visible} onDismiss={() => setVisible(false)}>
          <Dialog.Title>Novo Contato</Dialog.Title>
          <Dialog.Content>
            <TextInput 
              label='Tipo'
              mode='outlined'
              placeholder='Neto, Primo, Filho'
              value={tipo}
              onChangeText={(text) => setTipo(text)}
            />
            <TextInput 
              label='Nome'
              mode='outlined'
              placeholder='Maria Silva'
              value={nome}
              onChangeText={(text) => setNome(text)}
            />
            <TextInput 
              label='Telefone'
              mode='outlined'
              placeholder='(31) 99845-2288'
              keyboardType='phone-pad'
              value={telefone}
              onChangeText={(text) => setTelefone(text)}
            />
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={salvar}>Salvar</Button>
            <Button onPress={() => setVisible(false)}>Cancelar</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </Provider> 
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: Constants.statusBarHeight
  }
})

