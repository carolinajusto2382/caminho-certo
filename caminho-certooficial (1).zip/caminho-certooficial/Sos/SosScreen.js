import React, {useLayoutEffect, useEffect, useState} from 'react'
import {View, StyleSheet, Text} from 'react-native'
import {Button} from 'react-native-paper'
import MapView, {Marker} from 'react-native-maps'; 
import * as Location from 'expo-location';
import { MaterialIcons } from '@expo/vector-icons';
import * as Linking from 'expo-linking';

//const contato = {tipo: 'FILHA', nome: 'LARISSA', telefone: '31 98877-1122'}

export default ({navigation, route}) => {

  const contato = route.params.contato
  const [location, setLocation] = useState(null) 

  useLayoutEffect(() => {
    navigation.setOptions({title: `${contato.tipo} ${contato.nome}`})
  },[navigation])

  useEffect(() => {
    obterCoordenadas()
  }, [])

  const obterCoordenadas = async () => {
    let {status} = await Location.requestForegroundPermissionsAsync()

    if(status !== 'granted') {
      alert('Você precisa habilitar o serviço de localização do seu celular.')
    } else {
      let location = await Location.getCurrentPositionAsync()
      setLocation({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
        latitudeDelta: 0.005,
        longitudeDelta: 0.005,
      })
    }
  }

  return(
    <View style={styles.main}>
      <View style={styles.viewMapa}>
        <MapView style={styles.map} initialRegion={location}>
          {
            location != null && <Marker 
                                  coordinate={location}
                                  title='Você está aqui'
                                  description='Está é a sua posição'
                                >
                                  <MaterialIcons name="emoji-people" size={42} color="black" />
                                </Marker>
          }         
        </MapView>
      </View>
      <View style={styles.viewBotoes}>
        <Button mode="contained" style={styles.botao}>
          Enviar Localização
        </Button>
        <Button 
            mode="contained" 
            style={styles.botao}
            onPress={() => Linking.openURL(`tel:${contato.telefone}`)}
        >
          Dicar para {contato.nome}
        </Button>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  main: {
    flex: 1,
  },
  viewMapa: {
    flex: 1,
    backgroundColor: '#C0C0C0'
  },
  map: {
    flex: 1
  },  
  viewBotoes: {
    height: 130,
    justifyContent: 'space-evenly',
    paddingLeft: 10,
    paddingRight: 10
  },
  botao: {
    backgroundColor: '#25CCB0'
  }
})